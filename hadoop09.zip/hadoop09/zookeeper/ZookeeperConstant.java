package com.test.zookeeper;

public class ZookeeperConstant {
	public static final String URL = "192.168.72.128:2181";

}
