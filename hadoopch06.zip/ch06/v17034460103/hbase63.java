package hadoop.ch06.v17034460103;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.HBaseConfiguration;
import org.apache.hadoop.hbase.HColumnDescriptor;
import org.apache.hadoop.hbase.HTableDescriptor;
import org.apache.hadoop.hbase.TableName;
import org.apache.hadoop.hbase.client.Admin;
import org.apache.hadoop.hbase.client.Connection;
import org.apache.hadoop.hbase.client.ConnectionFactory;
public class hbase63 {
    private  static Configuration conf;
    private static String tableName;

    static {
        tableName = "emp103";
        conf = HBaseConfiguration.create();
        conf.set("hbase.zookeeper.quorum", "node0,node1,node2");
        conf.set("hbase.rootdir", "hdfs://node0:8020/hbase");
        conf.set("hbase.cluster.distributed", "true");
    }

    public static void main(String[] args) throws Exception{
        createTable();
        insert();
        get();
        scan();
    }

    private static void createTable() throws Exception{
        Connection connect =
                ConnectionFactory.createConnection(conf);
        Admin admin = connect.getAdmin();
        TableName tn = TableName.valueOf(tableName);
        String[] family=new String[]
                {"member_id","address","info"};
        HTableDescriptor desc = new HTableDescriptor(tn);
        for (int i = 0; i < family.length; i++) {
            desc.addFamily(new HColumnDescriptor(family[i]));
        }
        if (admin.tableExists(tn)) {
            System.out.println("table Exists!");
            System.exit(0);
        } else {
            admin.createTable(desc);
            System.out.println("create table  " + tableName + "  Success!");
        }
    }


    private static void insert() throws Exception{
        HTable table = new HTable(conf, tableName);
        Put put = new Put(Bytes.toBytes("Rain"));
        put.addColumn(Bytes.toBytes("member_id"), Bytes.toBytes(""), Bytes.toBytes("31"));
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("age"), Bytes.toBytes("28"));
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("birthday"), Bytes.toBytes("1990-05-01"));
        put.addColumn(Bytes.toBytes("info"), Bytes.toBytes("industry"), Bytes.toBytes("architect"));
        put.addColumn(Bytes.toBytes("address"), Bytes.toBytes("city"), Bytes.toBytes("ShenZhen"));
        put.addColumn(Bytes.toBytes("address"), Bytes.toBytes("country"), Bytes.toBytes("China"));
        table.put(put);
        System.out.println("insert Success!");
        table.close();
    }

    private static void get() throws Exception{
        HTable table = new HTable(conf, tableName);
        Get get = new Get(Bytes.toBytes("Rain"));
        get.addFamily(Bytes.toBytes("info"));
        Result result = table.get(get);
        String[] info = {Bytes.toString(result.getValue(Bytes.toBytes("info"),Bytes.toBytes("age"))),
                Bytes.toString(result.getValue(Bytes.toBytes("info"),Bytes.toBytes("birthday"))),
                Bytes.toString(result.getValue(Bytes.toBytes("info"),Bytes.toBytes("industry")))};
        System.out.println("info:age  value="+info[0]+"\n"+
                "info:birthday  value="+info[1]+"\n"+
                "info:industry  value="+info[2]+"\n");
        table.close();
    }

    private static void scan() throws Exception{
        HTable table = new HTable(conf, tableName);
        Scan scanner = new Scan();
        ResultScanner rs = table.getScanner(scanner);
        for (Result r:rs
             ) {
            String birthday = Bytes.toString(r.getValue(Bytes.toBytes("info"), Bytes.toBytes("birthday")));
            System.out.println("info:birthday = " + birthday);
        }
        table.close();
    }
}
}