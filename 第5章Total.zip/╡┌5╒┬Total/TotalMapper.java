package Total;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class TotalMapper extends Mapper<LongWritable, Text, IntWritable, Total> {
    @Override
    protected void map(LongWritable k1, Text v1, Context context) throws IOException,InterruptedException{
        String data = v1.toString();
        String[] words = data.split(",");
        //得到int年份，作为IntWritable k2输出  不知道Text k2的怎么样，还没试
        int year = Integer.parseInt(words[2].split("-")[0]);
        Total s = new Total();
        s.setYear(year);
        s.setQuantity_sold(Integer.parseInt(words[5]));
        s.setAmount_sold(Float.parseFloat(words[6]));
        context.write(new IntWritable(year), s);
    }
}

