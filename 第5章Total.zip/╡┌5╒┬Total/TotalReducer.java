package Total;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class TotalReducer extends Reducer<IntWritable, Total, IntWritable, Text> {
    @Override
    protected void reduce(IntWritable k3, Iterable<Total> v3, Context context)
            throws IOException, InterruptedException {
        int quantity_total = 0;
        float amount_total = 0;
        for (Total s:v3
        ) {
            quantity_total += s.getQuantity_sold();
            amount_total += s.getAmount_sold();
        }
        Text result = new Text("quantity_total: " + quantity_total + "\t" + "amount_total: " + amount_total);
        context.write(k3 ,result);
    }
}
