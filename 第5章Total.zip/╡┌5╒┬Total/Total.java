package Total;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class Total implements Writable {
    private int year;
    private int quantity_sold;
    private float amount_sold;

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getQuantity_sold() {
        return quantity_sold;
    }

    public void setQuantity_sold(int quantity_sold) {
        this.quantity_sold = quantity_sold;
    }

    public float getAmount_sold() {
        return amount_sold;
    }

    public void setAmount_sold(float amount_sold) {
        this.amount_sold = amount_sold;
    }

    @Override
    public void readFields(DataInput input) throws IOException {
        this.setYear(input.readInt());
        this.setQuantity_sold(input.readInt());
        this.setAmount_sold(input.readFloat());
    }
    @Override
    public  void write(DataOutput output) throws IOException{
        output.writeInt(this.year);
        output.writeInt(this.quantity_sold);
        output.writeFloat(this.amount_sold);
    }
}
