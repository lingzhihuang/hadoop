package SouGou;
import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

public class SouGou implements Writable {

    private String index0;
    private String index1;
    private String search;
    private int url_ranking;
    private int user_order;
    private String url;

    public String getIndex0() {
        return index0;
    }

    public void setIndex0(String index0) {
        this.index0 = index0;
    }

    public String getIndex1() {
        return index1;
    }

    public void setIndex1(String index1) {
        this.index1 = index1;
    }

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public int getUrl_ranking() {
        return url_ranking;
    }

    public void setUrl_ranking(int url_ranking) {
        this.url_ranking = url_ranking;
    }

    public int getUser_order() {
        return user_order;
    }

    public void setUser_order(int user_order) {
        this.user_order = user_order;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    @Override
    public void readFields(DataInput input) throws IOException {
        this.index0 = input.readUTF();
        this.index1 = input.readUTF();
        this.search = input.readUTF();
        this.url_ranking = input.readInt();
        this.user_order = input.readInt();
        this.url = input.readUTF();
    }
    @Override
    public void write(DataOutput output) throws IOException{
        output.writeUTF(this.index0);
        output.writeUTF(this.index1);
        output.writeUTF(this.search);
        output.writeInt(this.url_ranking);
        output.writeInt(this.user_order);
        output.writeUTF(this.url);
    }

}