package SouGou;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

public class SouGouReducer extends Reducer<IntWritable, SouGou, NullWritable, Text> {
    @Override
    protected void reduce(IntWritable k3, Iterable<SouGou> v3, Context context)
            throws IOException, InterruptedException {
        String record;
        StringBuilder result = new StringBuilder();
        for (SouGou s:v3
        ) {
            //k2 为2的,即url_ranking为2的,user_order属性为1的,符合条件
            if((k3.equals(new IntWritable(2)) && s.getUser_order() == 1)){
                record = s.getIndex0() + "\t" + s.getIndex1() + "\t" + s.getSearch() + "\t" + s.getUrl_ranking() +
                        "\t" + s.getUser_order() + "\t" + s.getUrl() + "\n";
                result.append(record);
            }
        }
        //不需要输出k3，所以输出空的k4
        context.write(NullWritable.get(), new Text(result.toString()));
    }
}

