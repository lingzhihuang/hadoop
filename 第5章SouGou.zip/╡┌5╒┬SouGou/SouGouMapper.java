package SouGou;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

public class SouGouMapper extends Mapper<LongWritable, Text, IntWritable, SouGou> {
    @Override
    protected void map(LongWritable k1, Text v1, Context context) throws IOException,InterruptedException {
        //毁灭所有空格，并且波及换行符，但是问题不大
        String data = v1.toString().replaceAll("\\s", "#");
        //用#分隔，数据中存在逗号，所以不用逗号分隔
        String[] words = data.split("#");
        int url_ranking = Integer.parseInt(words[3]);
        int user_order = Integer.parseInt(words[4]);
        //其实没必要搞序列化，直接传v1也行
        SouGou s = new SouGou();
        s.setIndex0(words[0]);
        s.setIndex1(words[1]);
        s.setSearch(words[2]);
        s.setUrl_ranking(url_ranking);
        s.setUser_order(user_order);
        s.setUrl(words[5]);
        context.write(new IntWritable(url_ranking), s);
    }
}

