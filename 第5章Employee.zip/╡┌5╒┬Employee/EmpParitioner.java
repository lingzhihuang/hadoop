package Employee;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.mapreduce.Partitioner;
/*
 *   建立分区规则，根据员工工资进行分区
 *   薪资<1500为低薪
 *   薪资≥1500，薪资<3000为中薪。
 *   薪资≥3000为高薪。
 */
public class EmpParitioner extends Partitioner<IntWritable, Employee>{
    // numPartition 参数：建立多少个分区
    public int getPartition(IntWritable k2, Employee v2, int numPartition){
        if (v2.getSal()<1500){
            //放入1号分区中
            return 1%numPartition;
        }else if (v2.getSal()>=1500 && v2.getSal()<3000){
            //放入2号分区中
            return 2%numPartition;
        }else{
            //放入0号分区中
            return 3%numPartition;
        }
    }
}
